
const getters={
  token:state=>state.user.token,
  expTime:state=>state.user.expTime,
  refreshTime:state=>state.user.refreshTime
}
export default getters;
